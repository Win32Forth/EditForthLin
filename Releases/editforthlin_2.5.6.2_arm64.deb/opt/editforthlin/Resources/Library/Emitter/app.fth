\ app.fth — FORTH entry points: EMIT-APP / EMIT-WINDOW-APP (+ -TO)
\ Requires save.fth (and thus target/reloc/run). Public domain.
\
\ Public words parse the entry name from the input stream so the .app
\ basename matches the word (not LAST-INCLUDED — a nested REQUIRE like
\ big-int.fth must not rename PIMAIN.app):
\   FROMLIB FLOAD Emitter/emitter.fth
\   EMIT-APP MAIN                      \ → <source-dir>\<STEM>\MAIN
\   FROMLIB EMIT-APP MAIN              \ no file yet → "." beside cwd
\   S" /tmp" EMIT-APP-TO MAIN          \ → /tmp/MAIN.exe
\
\ Window wrapper (APP-NAME + WINDOW … WINDOW-OFF). Basename = parsed
\ word; window title = stem of LAST-INCLUDED when set, else the word:
\   FROMLIB FLOAD Emitter/emitter.fth
\   S" …/tetra/tetra.fth" INCLUDED
\   EMIT-WINDOW-APP GAME               \ → …\tetra\TETRA\GAME , title TETRA
\   S" /tmp" EMIT-WINDOW-APP-TO GAME   \ explicit outdir, no stem folder
\ Pass a body that expects an open window (e.g. GAME), not MAIN.
\
\ Stack-based (xt) variants — naming follows NAME>STRING of the xt
\ (less reliable if you pass a :NONAME or alias):
\   ' MAIN EMIT-APP-XT
\   ' MAIN S" /tmp" EMIT-APP-XT-TO
\   ' GAME EMIT-WINDOW-APP-XT
\   ' GAME S" /tmp" EMIT-WINDOW-APP-XT-TO
\
\ Both wrap the entry in CATCH. Default EMIT-ON-THROW prints the code
\ then KEY DROP; override with ' MY-HANDLER IS EMIT-ON-THROW before
\ emitting. WINDOW-OFF still runs after the handler.
\
\ Forces /EMIT-STANDALONE + /EMIT-UNBOUND, TGT-BUILDs, SAVE-IMAGEs, then
\ EMIT-OS-PACK. The Mac packer runs Library/Emitter/app-build.sh (a .app).
\ Windows packaging is a separate file, app-win.fth. It redirects
\ EMIT-OS-MKDIR and EMIT-OS-PACK when cmd.exe is present. EMIT-APP and
\ EMIT-WINDOW-APP both use those two hooks.
\
\ Quiet log (host): EMIT-APP / EMIT-WINDOW-APP console chatter is captured to
\ <stem>.emit.log beside the .app; the Forth console gets a one-line summary.
\ Set environment EMIT_VERBOSE=1 to keep the full transcript on the console.

ONLY FORTH ALSO SYSVOC ALSO EMITTER DEFINITIONS
DECIMAL

512 CONSTANT /EMIT-PB
CREATE EMIT-APP-BUILD  /EMIT-PB ALLOT   \ counted path to app-build.sh (override OK)
CREATE EMIT-NAMEBUF    64 ALLOT         \ counted app basename / APP-NAME title
CREATE EMIT-IMGBUF     /EMIT-PB ALLOT   \ counted path to .img
CREATE EMIT-APPBUF     /EMIT-PB ALLOT   \ counted path to .app (message)
CREATE EMIT-CMDBUF     1024 ALLOT       \ counted SYSTEM command
CREATE EMIT-TMP        /EMIT-PB ALLOT
CREATE EMIT-OUTDIR     /EMIT-PB ALLOT   \ counted <source-dir>/<STEM> for EMIT-AUTO
CREATE EMIT-TITLE      64 ALLOT         \ counted title for SLITERAL into wrapper

: (EMIT-S0)  ( dest -- )  0 SWAP C! ;

: (EMIT-S+)  ( c-addr u dest -- )
  {: a u dest | n -- :}
  dest C@ TO n
  n u + /EMIT-PB 1- > IF
    ." EMIT-APP: path too long" CR ABORT
  THEN
  a  dest CHAR+ n +  u MOVE
  n u + dest C! ;

: (EMIT-CH+)  ( char dest -- )
  SWAP PAD C!  PAD 1 ROT (EMIT-S+) ;

: (EMIT-UPC)  ( c -- c' )
  DUP [CHAR] a >= OVER [CHAR] z <= AND IF  32 -  THEN ;

\ Absolute or ~ path? (does not consume FROMLIB)
\ `/…`, `\…`, `~…`, and a Windows drive (`C:…`) are absolute.
: (EMIT-ABS?)  ( c-addr u -- flag )
  DUP 0= IF  2DROP FALSE EXIT  THEN
  OVER C@ [CHAR] / = IF  2DROP TRUE EXIT  THEN
  OVER C@ [CHAR] \ = IF  2DROP TRUE EXIT  THEN
  OVER C@ [CHAR] ~ = IF  2DROP TRUE EXIT  THEN
  DUP 2 < IF  2DROP FALSE EXIT  THEN
  OVER 1+ C@ [CHAR] : <> IF  2DROP FALSE EXIT  THEN
  OVER C@ (EMIT-UPC)  DUP [CHAR] A <  SWAP [CHAR] Z >  OR IF
    2DROP FALSE EXIT
  THEN
  2DROP TRUE ;

\ Parent directory of a path (no trailing slash). No slash → S" ."
: (EMIT-PARENT-DIR)  ( c-addr u -- c-addr u' )
  {: a u | i -- :}
  u TO i
  BEGIN  i  WHILE
    i 1- TO i
    a i + C@ DUP [CHAR] / = SWAP [CHAR] \ = OR IF
      i 0= IF
        a C@ [CHAR] \ = IF  S" \" EXIT  THEN
        S" /" EXIT
      THEN
      a i EXIT
    THEN
  REPEAT
  S" ."
  ;

\ Resolve outdir: relative + FROMLIB? → under LIBRARY-PATH (then FROMLIB-OFF).
\ Absolute unchanged. "." is the directory of the last included source
\ file, so NAME\ sits beside that file. FLOAD restores the previous
\ process directory before INCLUDED returns, so CWD@ is not that folder.
\ With nothing included, "." is the process directory.
\ Other relative paths stay cwd-relative.
\ Result left counted in EMIT-TMP.
: (EMIT-RESOLVE-OUT)  ( c-addr u -- )
  {: a u | la lu n -- :}
  a u (EMIT-ABS?) IF
    a u EMIT-TMP PLACE  EXIT
  THEN
  u 1 =  a C@ [CHAR] . =  AND IF
    LAST-INCLUDED DUP IF
      (EMIT-PARENT-DIR) EMIT-TMP PLACE
    ELSE
      2DROP
      EMIT-TMP CHAR+ 500 CWD@ TO n
      n 0= IF
        a u EMIT-TMP PLACE
      ELSE
        n EMIT-TMP C!
      THEN
    THEN
    FROMLIB? IF  FROMLIB-OFF  THEN
    EXIT
  THEN
  FROMLIB? 0= IF
    a u EMIT-TMP PLACE  EXIT
  THEN
  LIBRARY-PATH TO lu TO la
  lu 0= IF
    ." EMIT-APP: LIBRARY-PATH empty (no Library)" CR ABORT
  THEN
  EMIT-TMP (EMIT-S0)
  la lu EMIT-TMP (EMIT-S+)
  \ "." already left above, beside the source file.
  u 1 =  a C@ [CHAR] . =  AND IF
    FROMLIB-OFF  EXIT
  THEN
  u IF
    [CHAR] / EMIT-TMP (EMIT-CH+)
    a u EMIT-TMP (EMIT-S+)
  THEN
  FROMLIB-OFF
  ;

\ Resolve app-build.sh via LIBRARY-PATH (does not consume user FROMLIB).
: (EMIT-RESOLVE-SH)  ( -- )
  EMIT-APP-BUILD C@ IF EXIT THEN
  LIBRARY-PATH DUP 0= IF
    2DROP ." EMIT-APP: LIBRARY-PATH empty (set EMIT-APP-BUILD)" CR ABORT
  THEN
  EMIT-APP-BUILD PLACE
  S" /Emitter/app-build.sh" EMIT-APP-BUILD (EMIT-S+)
  EMIT-APP-BUILD COUNT FILE-STATUS NIP IF
    ." EMIT-APP: app-build.sh missing: " EMIT-APP-BUILD COUNT TYPE CR ABORT
  THEN ;

: (EMIT-APP-NAME!)  ( xt -- )
  NAME>STRING DUP 0= IF
    2DROP ." EMIT-APP: empty word name" CR ABORT
  THEN
  DUP 63 > IF  2DROP ." EMIT-APP: name too long" CR ABORT  THEN
  EMIT-NAMEBUF PLACE ;

\ Path → uppercase stem in EMIT-NAMEBUF (…/tetra.fth → TETRA).
: (EMIT-STEM-UPPER!)  ( c-addr u -- )
  {: a u | i base blen -- :}
  0 TO base
  0 TO i
  BEGIN  i u <  WHILE
    a i + C@ DUP [CHAR] / = SWAP [CHAR] \ = OR IF  i 1+ TO base  THEN
    i 1+ TO i
  REPEAT
  u base - TO blen
  a base + TO a
  \ strip final .ext if present
  blen TO i
  BEGIN  i  WHILE
    i 1- TO i
    a i + C@ [CHAR] . = IF
      i TO blen
      0 TO i
    THEN
  REPEAT
  blen 0= IF  ." EMIT-WINDOW-APP: empty stem" CR ABORT  THEN
  blen 63 > IF  ." EMIT-WINDOW-APP: stem too long" CR ABORT  THEN
  EMIT-NAMEBUF (EMIT-S0)
  0 TO i
  BEGIN  i blen <  WHILE
    a i + C@ (EMIT-UPC) EMIT-NAMEBUF (EMIT-CH+)
    i 1+ TO i
  REPEAT
  ;

\ Window title only (EMIT-TITLE). Does not touch EMIT-NAMEBUF (basename).
\ Prefers LAST-INCLUDED stem; else xt name (uppercased).
\ Consumes xt from the stack; caller keeps its own copy (e.g. local).
: (EMIT-TITLE!)  ( xt -- )
  {: xt | -- :}
  LAST-INCLUDED DUP IF
    (EMIT-STEM-UPPER!)                 \ path → EMIT-NAMEBUF temp
  ELSE
    2DROP
    xt NAME>STRING DUP 0= IF
      2DROP ." EMIT-WINDOW-APP: no LAST-INCLUDED and empty xt name" CR ABORT
    THEN
    (EMIT-STEM-UPPER!)
  THEN
  EMIT-NAMEBUF COUNT EMIT-TITLE PLACE
  ;

\ Join outdir + "/" + name + suffix → dest counted string.
: (EMIT-JOIN)  ( out-addr out-u name-addr name-u suffix-addr suffix-u dest -- )
  {: oa ou na nu sa su dest -- :}
  dest (EMIT-S0)
  oa ou dest (EMIT-S+)
  ou IF
    oa ou + 1- C@ DUP [CHAR] / = SWAP [CHAR] \ = OR 0= IF
      [CHAR] / dest (EMIT-CH+)
    THEN
  THEN
  na nu dest (EMIT-S+)
  sa su dest (EMIT-S+) ;

: (EMIT-QUOTE+)  ( c-addr u dest -- )  \ append '…' (no escaping; Forth names are plain)
  {: a u dest -- :}
  [CHAR] ' dest (EMIT-CH+)
  a u dest (EMIT-S+)
  [CHAR] ' dest (EMIT-CH+) ;

: (EMIT-MKDIR)  ( c-addr u -- )
  {: a u -- :}
  u 1 = IF  a C@ [CHAR] . = IF  EXIT  THEN THEN
  EMIT-CMDBUF (EMIT-S0)
  S" mkdir -p " EMIT-CMDBUF (EMIT-S+)
  a u EMIT-CMDBUF (EMIT-QUOTE+)
  EMIT-CMDBUF COUNT SYSTEM IF
    ." EMIT-APP: mkdir failed: " a u TYPE CR
    ."   (need a writable folder beside the source; bundle Resources are read-only)" CR
    ABORT
  THEN ;

: (EMIT-PACK)  ( -- )  \ uses EMIT-NAMEBUF, EMIT-IMGBUF, outdir left in EMIT-TMP
  (EMIT-RESOLVE-SH)
  EMIT-CMDBUF (EMIT-S0)
  \ sh so a 644 copy still runs (GitHub does not store the executable bit here).
  S" sh " EMIT-CMDBUF (EMIT-S+)
  EMIT-APP-BUILD COUNT EMIT-CMDBUF (EMIT-QUOTE+)
  BL EMIT-CMDBUF (EMIT-CH+)
  EMIT-NAMEBUF COUNT EMIT-CMDBUF (EMIT-QUOTE+)
  BL EMIT-CMDBUF (EMIT-CH+)
  EMIT-IMGBUF COUNT EMIT-CMDBUF (EMIT-QUOTE+)
  BL EMIT-CMDBUF (EMIT-CH+)
  EMIT-TMP COUNT EMIT-CMDBUF (EMIT-QUOTE+)
  EMIT-CMDBUF COUNT SYSTEM IF
    ." EMIT-APP: app-build.sh failed" CR
    ."   cmd: " EMIT-CMDBUF COUNT TYPE CR ABORT
  THEN
  CR ." EMIT-APP: built " EMIT-APPBUF COUNT TYPE CR
  ."   image: " EMIT-IMGBUF COUNT TYPE CR
  ."   open " EMIT-APPBUF COUNT TYPE CR ;

\ Mac defaults. app-win.fth retargets both when this process is Windows.
\ EMIT-APP and EMIT-WINDOW-APP share the hooks.
DEFER EMIT-OS-MKDIR
DEFER EMIT-OS-PACK
' (EMIT-MKDIR) IS EMIT-OS-MKDIR
' (EMIT-PACK) IS EMIT-OS-PACK

: (EMIT-SAVE+PACK)  ( xt c-addr u -- )
  {: xt oa ou -- :}
  oa ou (EMIT-RESOLVE-OUT)          \ → EMIT-TMP; may consume FROMLIB
  xt (EMIT-APP-NAME!)
  EMIT-TMP COUNT EMIT-OS-MKDIR
  EMIT-TMP COUNT  EMIT-NAMEBUF COUNT  S" .img"  EMIT-IMGBUF  (EMIT-JOIN)
  EMIT-TMP COUNT  EMIT-NAMEBUF COUNT  S" .app"  EMIT-APPBUF  (EMIT-JOIN)
  /EMIT-CONSOLE                     \ terminal I/O (SA-PRINT → write(1))
  /EMIT-STANDALONE
  /EMIT-UNBOUND
  xt TGT-BUILD
  xt EMIT-IMGBUF COUNT SAVE-IMAGE
  EMIT-OS-PACK ;

\ Like (EMIT-SAVE+PACK) but EMIT-NAMEBUF already set (for :NONAME wrappers).
\ Caller arms /EMIT-WINDOW or /EMIT-CONSOLE before this (see *-APP-XT-TO).
: (EMIT-SAVE+PACK-NAMED)  ( xt c-addr u -- )
  {: xt oa ou -- :}
  oa ou (EMIT-RESOLVE-OUT)
  EMIT-NAMEBUF C@ 0= IF
    ." EMIT-WINDOW-APP: empty app name" CR ABORT
  THEN
  EMIT-TMP COUNT EMIT-OS-MKDIR
  EMIT-TMP COUNT  EMIT-NAMEBUF COUNT  S" .img"  EMIT-IMGBUF  (EMIT-JOIN)
  EMIT-TMP COUNT  EMIT-NAMEBUF COUNT  S" .app"  EMIT-APPBUF  (EMIT-JOIN)
  /EMIT-STANDALONE
  /EMIT-UNBOUND
  xt TGT-BUILD
  xt EMIT-IMGBUF COUNT SAVE-IMAGE
  EMIT-OS-PACK ;

\ --- public FORTH API ---
ONLY FORTH DEFINITIONS
ALSO SYSVOC ALSO EMITTER

\ Auto-CATCH handler (n -- ). Override before EMIT-APP / EMIT-WINDOW-APP:
\   : MY-THROW  ( n -- )  ... ;  ' MY-THROW IS EMIT-ON-THROW
\ Default prints the code then KEY DROP so the message stays visible before
\ exit; WINDOW-OFF still runs after the handler in the window wrap.

DEFER EMIT-ON-THROW

\ :NONAME  <xt> CATCH ?DUP IF <handler> THEN ;
\ Captures ACTION-OF EMIT-ON-THROW at wrap time.
\ LITERAL must be POSTPONEd: bare LITERAL is IMMEDIATE and would run while
\ compiling this word (stack underflow), not while compiling the :NONAME.
: (EMIT-CATCH-WRAP)  ( xt -- wxt )
  {: xt | h -- :}
  ACTION-OF EMIT-ON-THROW TO h
  :NONAME
    xt POSTPONE LITERAL
    POSTPONE CATCH
    POSTPONE ?DUP
    POSTPONE IF
      h COMPILE,
    POSTPONE THEN
  POSTPONE ;
  ;

\ Non-window EMIT-APP: FORTH TYPE + KEY (terminal).
: (EMIT-ON-THROW-DEFAULT)  ( n -- )
  S" exception " TYPE
  BASE @ >R  DECIMAL
  DUP 0< IF  S" -" TYPE  ABS  THEN
  S>D <# #S #> TYPE
  R> BASE !
  S\" \r\npress any key to exit " TYPE
  KEY DROP
  S\" \r\n" TYPE
  ;

\ Resolve GRAPHICS words by wid (not search order) so we never bind kernel KEY.
: (EMIT-GFX-XT)  ( c-addr u -- xt )
  2DUP GRAPHICS-WID SEARCH-WORDLIST
  ?DUP 0= IF  ." EMIT: missing GRAPHICS " TYPE CR ABORT  THEN
  DROP >R 2DROP R> ;

S" KEY"        (EMIT-GFX-XT) CONSTANT (EMIT-GFX-KEY)
S" WINDOW"     (EMIT-GFX-XT) CONSTANT (EMIT-GFX-WINDOW)
S" WINDOW-OFF" (EMIT-GFX-XT) CONSTANT (EMIT-GFX-WINDOW-OFF)
S" APP-NAME"   (EMIT-GFX-XT) CONSTANT (EMIT-GFX-APP-NAME)
S" TYPE"       (EMIT-GFX-XT) CONSTANT (EMIT-GFX-TYPE)
S" CR"         (EMIT-GFX-XT) CONSTANT (EMIT-GFX-CR)

\ Error path only — success-path KEY belongs in the app source (e.g. PIMAIN),
\ same as tetra: ONLY FORTH ALSO GRAPHICS … KEY … Host (APP-KEY) waits;
\ see emit-host.inc.
: (EMIT-ON-THROW-WIN)  ( n -- )
  S" exception " (EMIT-GFX-TYPE) EXECUTE
  BASE @ >R  DECIMAL
  DUP 0< IF  S" -" (EMIT-GFX-TYPE) EXECUTE  ABS  THEN
  S>D <# #S #> (EMIT-GFX-TYPE) EXECUTE
  R> BASE !
  S\" \r\npress any key to exit " (EMIT-GFX-TYPE) EXECUTE
  (EMIT-GFX-KEY) EXECUTE DROP
  S\" \r\n" (EMIT-GFX-TYPE) EXECUTE
  ;

\ Host GRAPHICS session is copied into the image (VALUE / VARIABLE cells).
\ CLOCK.fth ends with CR after ONLY FORTH ALSO GRAPHICS, so the load opens
\ the host window: G-OPEN? = -1 and G-BUF = that process's ALLOCATE.
\ Stand-alone WINDOW then returns immediately and EMIT writes the stale
\ pointer (access violation). Close the host window and zero the cells
\ before the snapshot. -1 is a kept immediate, so the pointer sanitizer
\ does not clear G-OPEN?.
: (EMIT-RESET-GFX)  ( -- )
  (EMIT-GFX-WINDOW-OFF) EXECUTE
  S" G-FREE-BUF" (EMIT-GFX-XT) EXECUTE
  0 S" G-OPEN?"  (EMIT-GFX-XT) >BODY !
  0 S" G-DIRTY?" (EMIT-GFX-XT) >BODY !
  0 S" G-CX"     (EMIT-GFX-XT) >BODY !
  0 S" G-CY"     (EMIT-GFX-XT) >BODY !
;

\ :NONAME  title APP-NAME WINDOW
\   <xt> CATCH ?DUP IF win-handler THEN
\   WINDOW-OFF ;
\ No automatic KEY here — EMIT-NO-PAUSE / EMIT-NO-WRAPPER paths use this.
: (EMIT-WIN-WRAP)  ( xt c-addr u -- wxt )
  {: xt a u -- :}
  :NONAME
  a u POSTPONE SLITERAL
  (EMIT-GFX-APP-NAME)   POSTPONE LITERAL POSTPONE EXECUTE
  (EMIT-GFX-WINDOW)     POSTPONE LITERAL POSTPONE EXECUTE
  xt POSTPONE LITERAL
  POSTPONE CATCH
  POSTPONE ?DUP
  POSTPONE IF
    ['] (EMIT-ON-THROW-WIN) COMPILE,
  POSTPONE THEN
  (EMIT-GFX-WINDOW-OFF) POSTPONE LITERAL POSTPONE EXECUTE
  POSTPONE ;
  ;

\ Default editor EMIT wrap: WINDOW, run xt, ." Press a key to exit" KEY DROP, WINDOW-OFF.
\ Exception path still uses (EMIT-ON-THROW-WIN) (already waits for a key).
: (EMIT-WIN-WRAP-PAUSE)  ( xt c-addr u -- wxt )
  {: xt a u -- :}
  :NONAME
  a u POSTPONE SLITERAL
  (EMIT-GFX-APP-NAME)   POSTPONE LITERAL POSTPONE EXECUTE
  (EMIT-GFX-WINDOW)     POSTPONE LITERAL POSTPONE EXECUTE
  xt POSTPONE LITERAL
  POSTPONE CATCH
  POSTPONE ?DUP
  POSTPONE IF
    ['] (EMIT-ON-THROW-WIN) COMPILE,
  POSTPONE ELSE
    \ Same text as ." Press a key to exit" then KEY DROP (GRAPHICS I/O).
    S" Press a key to exit" POSTPONE SLITERAL
    (EMIT-GFX-TYPE) POSTPONE LITERAL POSTPONE EXECUTE
    (EMIT-GFX-CR)   POSTPONE LITERAL POSTPONE EXECUTE
    (EMIT-GFX-KEY)  POSTPONE LITERAL POSTPONE EXECUTE
    POSTPONE DROP
  POSTPONE THEN
  (EMIT-GFX-WINDOW-OFF) POSTPONE LITERAL POSTPONE EXECUTE
  POSTPONE ;
  ;

' (EMIT-ON-THROW-DEFAULT) IS EMIT-ON-THROW

\ Parse "<name>" from the input stream → xt (ABORT if undefined).
: (EMIT-PARSE-XT)  ( -- xt )
  BL WORD FIND DUP 0= IF
    DROP COUNT ." EMIT-APP: undefined " TYPE CR ABORT
  THEN
  DROP ;

\ ONLY FORTH DEFINITIONS
\ ALSO SYSVOC ALSO EMITTER

\ --- stack-based (xt) ---

: EMIT-APP-XT-TO  ( xt c-addr u -- )
  {: xt a u -- :}
  /EMIT-CONSOLE                       \ FORTH I/O stays console / SA-PRINT
  xt (EMIT-APP-NAME!)                 \ basename from xt (not :NONAME wrap)
  xt (EMIT-CATCH-WRAP) TO xt
  xt a u (EMIT-SAVE+PACK-NAMED) ;

: EMIT-WINDOW-APP-XT-TO  ( xt c-addr u -- )
  {: xt a u -- :}
  (EMIT-RESET-GFX)
  /EMIT-WINDOW                        \ remap FORTH EMIT/TYPE/… → GRAPHICS
  xt (EMIT-APP-NAME!)                 \ basename from entry xt
  xt (EMIT-TITLE!)                    \ EMIT-TITLE from stem; clobbers NAMEBUF
  xt (EMIT-APP-NAME!)                 \ restore basename
  xt EMIT-TITLE COUNT (EMIT-WIN-WRAP) TO xt
  xt a u (EMIT-SAVE+PACK-NAMED) ;

\ --- public: parse name from input; path on stack for *-TO ---

: EMIT-APP-TO  ( c-addr u -- )        \ S" /tmp" EMIT-APP-TO MAIN
  (EMIT-PARSE-XT) -ROT EMIT-APP-XT-TO ;

: EMIT-WINDOW-APP-TO  ( c-addr u -- ) \ S" /tmp" EMIT-WINDOW-APP-TO PIMAIN
  (EMIT-PARSE-XT) -ROT EMIT-WINDOW-APP-XT-TO ;

\ =============================================================================
\ SYSTEM helpers — open Terminal / launch .app / run last EMIT product.
\ SYSTEM is host-hooked in EditForth and HOST-APP slot 31 in stand-alone.
\ Paths are single-quoted for /bin/sh (same as (EMIT-MKDIR) / app-build).
\ =============================================================================

\ open -a Terminal '<dir>'  — macOS Terminal at that folder.
: OPEN-TERMINAL-AT  ( c-addr u -- n )
  {: a u -- :}
  EMIT-CMDBUF (EMIT-S0)
  S" open -a Terminal " EMIT-CMDBUF (EMIT-S+)
  a u EMIT-CMDBUF (EMIT-QUOTE+)
  EMIT-CMDBUF COUNT SYSTEM ;

\ open '<path.app>'  — launch a macOS .app (or any path open(1) accepts).
: OPEN-APP  ( c-addr u -- n )
  {: a u -- :}
  EMIT-CMDBUF (EMIT-S0)
  S" open " EMIT-CMDBUF (EMIT-S+)
  a u EMIT-CMDBUF (EMIT-QUOTE+)
  EMIT-CMDBUF COUNT SYSTEM ;

\ Launch the .app path left in EMIT-APPBUF by the last successful EMIT-*.
: RUN-EMITTED  ( -- n )
  EMIT-APPBUF C@ 0= IF
    ." RUN-EMITTED: no .app yet (EMIT first)" CR
    -1 EXIT
  THEN
  EMIT-APPBUF COUNT OPEN-APP ;

\ Example: Terminal on the EditForth Documents tree.
: EDITFORTH-TERM  ( -- n )
  S" /Users/thomaszimmer/Documents/EditForth" OPEN-TERMINAL-AT ;

\ Example: open GCLOCK.app under Sample (after it has been emitted).
: EDITFORTH-GCLOCK  ( -- n )
  S" /Users/thomaszimmer/Documents/EditForth/Library/Sample/GCLOCK/GCLOCK.app"
  OPEN-APP ;

\ =============================================================================
\ Editor EMIT directives (FORTH). Put near the top of the main source file.
\ Flags are sticky until EMIT-FLAGS-RESET (editor INCLUDE resets them).
\
\   (none)            Window app: wrap LAST with WINDOW + "Press a key to exit"
\                     + KEY DROP. .app basename = main file stem (LAST-INCLUDED).
\   EMIT-NO-PAUSE     Window wrap without the pause (long-running / interactive).
\   EMIT-NO-WINDOW    Terminal/stdout stand-alone (EMIT-APP style). Implies no
\                     pause — run from Terminal, not double-click.
\   EMIT-NO-WRAPPER   Power user: emit LAST as-is via EMIT-WINDOW-APP / EMIT-APP
\                     (existing wraps only). Use only if you set up WINDOW/KEY
\                     yourself (e.g. sample GRAPHICS programs).
\ =============================================================================

VARIABLE EMIT-OPT

: EMIT-FLAGS-RESET  ( -- )  0 EMIT-OPT ! ;

: EMIT-NO-PAUSE  ( -- )  EMIT-OPT @ 1 OR EMIT-OPT ! ;

: EMIT-NO-WINDOW  ( -- )  EMIT-OPT @ 2 OR EMIT-OPT ! ;

: EMIT-NO-WRAPPER  ( -- )  EMIT-OPT @ 4 OR EMIT-OPT ! ;

: EMIT-NO-PAUSE?    ( -- flag )  EMIT-OPT @ 1 AND 0<> ;
: EMIT-NO-WINDOW?   ( -- flag )  EMIT-OPT @ 2 AND 0<> ;
: EMIT-NO-WRAPPER?  ( -- flag )  EMIT-OPT @ 4 AND 0<> ;

\ Stem already in EMIT-NAMEBUF / EMIT-TITLE — pack LAST per EMIT-OPT into outdir.
: (EMIT-AUTO-PACK)  ( oa ou -- )
  {: oa ou | xt -- :}
  LAST DUP 0= IF
    DROP ." EMIT-AUTO: no LAST definition" CR ABORT
  THEN
  TO xt

  EMIT-NO-WRAPPER? IF
    EMIT-NO-WINDOW? IF
      /EMIT-CONSOLE
      xt (EMIT-CATCH-WRAP) TO xt
      xt oa ou (EMIT-SAVE+PACK-NAMED)
    ELSE
      /EMIT-WINDOW
      xt EMIT-TITLE COUNT (EMIT-WIN-WRAP) TO xt
      xt oa ou (EMIT-SAVE+PACK-NAMED)
    THEN
    EXIT
  THEN

  EMIT-NO-WINDOW? IF
    /EMIT-CONSOLE
    xt (EMIT-CATCH-WRAP) TO xt
    xt oa ou (EMIT-SAVE+PACK-NAMED)
    EXIT
  THEN

  /EMIT-WINDOW
  EMIT-NO-PAUSE? IF
    xt EMIT-TITLE COUNT (EMIT-WIN-WRAP) TO xt
  ELSE
    xt EMIT-TITLE COUNT (EMIT-WIN-WRAP-PAUSE) TO xt
  THEN
  xt oa ou (EMIT-SAVE+PACK-NAMED)
  ;

\ Main-file path → NAMEBUF/TITLE stem (not a nested INCLUDE's path).
: (EMIT-AUTO-STEM-FROM)  ( c-addr u -- )
  DUP 0= IF
    2DROP ." EMIT-AUTO: empty main-file path" CR ABORT
  THEN
  (EMIT-STEM-UPPER!)
  EMIT-NAMEBUF COUNT EMIT-TITLE PLACE
  ;

\ After NAMEBUF stem is set: EMIT-OUTDIR = <parent-of-file>/<STEM>
\ e.g. …/Sample/HELLO.fth → …/Sample/HELLO  (holds HELLO.app / .img / .emit.log)
: (EMIT-AUTO-OUTDIR!)  ( file-addr file-u -- )
  {: fa fu | da du -- :}
  fa fu (EMIT-PARENT-DIR) TO du TO da
  EMIT-OUTDIR (EMIT-S0)
  da du EMIT-OUTDIR (EMIT-S+)
  du IF
    da du + 1- C@ DUP [CHAR] / = SWAP [CHAR] \ = OR 0= IF
      [CHAR] / EMIT-OUTDIR (EMIT-CH+)
    THEN
  ELSE
    [CHAR] / EMIT-OUTDIR (EMIT-CH+)
  THEN
  EMIT-NAMEBUF COUNT EMIT-OUTDIR (EMIT-S+)
  ;

\ Default outdir when the caller does not pass one.
\ Last included file → <source-dir>/<STEM>/ (exe, image, and log beside it).
\ No file yet → "." so cwd / FROMLIB still apply.
: (EMIT-BESIDE-OUT)  ( -- c-addr u )
  LAST-INCLUDED DUP 0= IF
    2DROP S" ." EXIT
  THEN
  FROMLIB-OFF
  2DUP (EMIT-AUTO-STEM-FROM)
  (EMIT-AUTO-OUTDIR!)
  EMIT-OUTDIR COUNT ;

: EMIT-APP-XT  ( xt -- )
  (EMIT-BESIDE-OUT) EMIT-APP-XT-TO ;

: EMIT-WINDOW-APP-XT  ( xt -- )
  (EMIT-BESIDE-OUT) EMIT-WINDOW-APP-XT-TO ;

: EMIT-APP  ( -- )                    \ EMIT-APP MAIN
  (EMIT-BESIDE-OUT) EMIT-APP-TO ;

: EMIT-WINDOW-APP  ( -- )             \ EMIT-WINDOW-APP PIMAIN
  (EMIT-BESIDE-OUT) EMIT-WINDOW-APP-TO ;

\ Editor EMIT: S" /path/main.fth" EMIT-AUTO-FILE-TO <outdir>
: EMIT-AUTO-FILE-TO  ( file-addr file-u out-addr out-u -- )
  {: fa fu oa ou -- :}
  fa fu (EMIT-AUTO-STEM-FROM)
  oa ou (EMIT-AUTO-PACK)
  ;

\ Default: artifacts in <source-dir>/<STEM>/ beside the main .fth.
: EMIT-AUTO-FILE  ( c-addr u -- )
  {: fa fu -- :}
  fa fu (EMIT-AUTO-STEM-FROM)
  fa fu (EMIT-AUTO-OUTDIR!)
  EMIT-OUTDIR COUNT (EMIT-AUTO-PACK)
  ;

\ Console helper with explicit outdir; stem from LAST-INCLUDED.
: EMIT-AUTO-TO  ( c-addr u -- )
  {: oa ou -- :}
  LAST-INCLUDED DUP 0= IF
    2DROP ." EMIT-AUTO: INCLUDE a main file first (LAST-INCLUDED empty)" CR ABORT
  THEN
  (EMIT-AUTO-STEM-FROM)
  oa ou (EMIT-AUTO-PACK)
  ;

\ Default EMIT-AUTO: same beside-source folder as EMIT-AUTO-FILE.
: EMIT-AUTO  ( -- )
  LAST-INCLUDED DUP 0= IF
    2DROP ." EMIT-AUTO: INCLUDE a main file first (LAST-INCLUDED empty)" CR ABORT
  THEN
  EMIT-AUTO-FILE
  ;

