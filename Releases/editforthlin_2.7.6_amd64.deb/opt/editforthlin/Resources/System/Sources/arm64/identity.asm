; Version and build time for this kernel image.
; The console banner and the editor About box read these bytes.
; The x64 image has its own copy, so the two builds can differ.

        AREA |.rdata|, DATA, READONLY, ALIGN=3

        EXPORT kernel_version
        EXPORT kernel_built
        EXPORT kernel_console

kernel_version  DCB     "2.7.6", 0
        ALIGN   8
kernel_built    DCB     "Nov 24, 2026 6:27 PM", 0
        ALIGN   8
kernel_console  DCB     "EditForthLin arm64", 0
        ALIGN   8

        END
